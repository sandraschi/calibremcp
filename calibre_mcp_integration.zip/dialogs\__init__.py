# Dialogs for CalibreMCP Integration plugin
